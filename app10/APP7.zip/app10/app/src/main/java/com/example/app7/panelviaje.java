package com.example.app7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class panelviaje extends AppCompatActivity {

    Spinner viaje, conductor;
    Button pasajeros;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panelviaje);
        viaje = (Spinner) findViewById(R.id.idrutasdeviaje);
        conductor =(Spinner)findViewById(R.id.idconductor);
        pasajeros = (Button)findViewById(R.id.btnpasajeros);

        //para los conductores
        String[] choferes = {"Saravia Castilla, Miguel Arturo",";Mendoza Linares, Jaimito gustavo","Yalan Garcia, Issac Miguel","Quispe Castilla,Wilmer Alberto"};
        ArrayAdapter<String> choferesspiner = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,choferes);
        choferesspiner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conductor.setAdapter(choferesspiner);

        conductor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String opcionSeleccionada = parent.getItemAtPosition(position).toString();
                Toast.makeText(panelviaje.this, "Seleccionaste: " + opcionSeleccionada, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });///fin de seleccion del conductor

        ///para las rutas
        String[] opciones = {"Chincha/Universidad", "Quilmaná/Universidad","Lunahuaná/Universidad","Mala/Universidad"};
        ArrayAdapter<String> opcionesspiner= new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        opcionesspiner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        viaje.setAdapter(opcionesspiner);

        //mostrar la eleccion
        viaje.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Obtiene la opción seleccionada
                String opcionSeleccionada = parent.getItemAtPosition(position).toString();
                // Realiza alguna acción según la opción seleccionada
                Toast.makeText(panelviaje.this, "Seleccionaste: " + opcionSeleccionada, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Método requerido, pero no lo estamos utilizando en este ejemplo
            }
        });//fin de mostrar la eleccion

        //para registrar pasajeros
        pasajeros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pasajerosbus = new Intent(panelviaje.this,panelregistrar.class);
                startActivity(pasajerosbus);
            }
        });//fin boton pasajeros

    }
}