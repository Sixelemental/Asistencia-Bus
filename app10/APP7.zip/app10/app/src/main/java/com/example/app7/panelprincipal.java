package com.example.app7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class panelprincipal extends AppCompatActivity {

    String enlacerutas,delegado;
    Button rutas,asistencia,registro;
    TextView tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panelprincipal);
        enlacerutas ="https://drive.google.com/file/d/1dEEMWSZmuukHd0mw2755JQfFq4IRbGuk/view?fbclid=IwAR2rayHhZbczbo4tDBe8jqO2AKznSh0v9Bv5tmQU1YrfasVQn5YA1EmK9Tk_aem_AYOG0_bV9wA-Fxnpbv-ja2D3ENPM7gGDE55OheZg4KeKKTasCUdtpeJuiyyVEuS7n1b2lum-alRBmuY3-EO_65BJ";
        rutas = (Button)findViewById(R.id.btnrutas);
        asistencia = (Button)findViewById(R.id.btnasistencia);
        registro = (Button)findViewById(R.id.btnregistrar);
        delegado = getIntent().getStringExtra("delegado");
        tipo = (TextView)findViewById(R.id.txttipousuario);

        //creando el boton de enlaces ruta
        rutas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uriruta=Uri.parse(enlacerutas);
                Intent rutabus=new Intent(Intent.ACTION_VIEW,uriruta);
                startActivity(rutabus);
            }
        });

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrarviaje = new Intent(panelprincipal.this, panelviaje.class);
                startActivity(registrarviaje);
            }
        });

        //ingresando al modo delegado
        if(delegado != null && delegado.equals("2002010016")){
            registro.setVisibility(View.VISIBLE);
            tipo.setText("DELEGADO");
        }
        else{registro.setVisibility(View.GONE);
            tipo.setText("ORDINARIO");
        }

    }
}