package com.example.app7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class panelregistrar extends AppCompatActivity {

    Spinner documento;
    EditText numero;
    Button buscar,qr,lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panelregistrar);
        documento = (Spinner) findViewById(R.id.sptipodocumento);
        buscar = (Button)findViewById(R.id.btnbuscar);
        qr=(Button)findViewById(R.id.btnqr);
        lista=(Button)findViewById(R.id.btnlistadeasistencia);

        //creando las opciones del spinner
        String[] opciones = {"Código Universitario", "DNI"};
        ArrayAdapter<String> opcionesspiner= new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        opcionesspiner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        documento.setAdapter(opcionesspiner);

        //mostrar la eleccion
        documento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Obtiene la opción seleccionada
                String opcionSeleccionada = parent.getItemAtPosition(position).toString();

                // Realiza alguna acción según la opción seleccionada
                Toast.makeText(panelregistrar.this, "Seleccionaste: " + opcionSeleccionada, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Método requerido, pero no lo estamos utilizando en este ejemplo
            }
        });//fin de mostrar la eleccion

        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buscarusuario = new Intent(panelregistrar.this,panelusuario.class);
                startActivity(buscarusuario);
            }
        });

        qr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buscarqr = new Intent(panelregistrar.this,panelqr.class);
                startActivity(buscarqr);
            }
        });

        lista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
