package com.example.app7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usuario, contraseña;
    Button ingresar;
    int n=0; //n es el contador de errores

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario = (EditText)findViewById(R.id.edittextusuario);
        contraseña = (EditText) findViewById(R.id.edittextcontrasena);
        ingresar = (Button) findViewById(R.id.btningresar);


        //para ingresar al boton
        ingresar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //obteniendo los valores de los edittext
                    String usuarioText = usuario.getText().toString().trim();
                    String contraseñaText = contraseña.getText().toString();

                    if (usuarioText.equals("2002010200") && contraseñaText.equals("70602726")) {
                        Intent principal = new Intent(MainActivity.this, panelprincipal.class);
                        principal.putExtra("delegado",usuarioText);
                        startActivity(principal);
                    }
                    if (usuarioText.equals("2002010016") && contraseñaText.equals("72752672")) {
                        Intent principal = new Intent(MainActivity.this, panelprincipal.class);
                        principal.putExtra("delegado",usuarioText);
                        startActivity(principal);}
                    else
                    {
                        n=n+1;
                        if(n==1){mensajeerror();}else{mensajealerta();}
                    }
                }//cerrado del codigo del boton
            });//cerrado del boton

    }//seccion codigo

    //creando la funcion del botón error
    private void mensajeerror() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("El usuario/contraseña estan incorrecto, volver a intentar")
                .setTitle("Error de ingreso")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Cerrar el diálogo
                        dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }//cerrado de la funcion mensajeerror

    //creando la funcion del botón alerta
    private void mensajealerta() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Los datos ingresados estan incorrectos, por favor asistir a la oficina de la universidad y consultar sus datos.")
                .setTitle("Alerta de ingreso")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Cerrar el diálogo
                        dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }//cerrado de la funcion mensajealerta

}//seccion principal
